public class W01dot1 {

    public static void main(String[] args) {
        // Displays my name, CIT260 and section, home town, and favorite dessert.
        System.out.println("Cayla Tribett");
        System.out.println("CIT260-03");
        System.out.println("Findlay, OH");
        System.out.println("Fruit");
    }
}